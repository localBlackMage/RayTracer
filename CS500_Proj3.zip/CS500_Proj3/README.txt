Prof. Herron,

Turns out I was seeing a fair amount of NAN results, stemming from the omega I dot m calculation being 0 within PdfBRDF.

-Holden Profit