Prof. Herron,

Pardon the delay in submission. The problem ended up being extremely small as I suspected. Within the extended path area of the algorithm, I was using Q's material to perform the BRDF lighting which was contributing excess light to the scene. I changed it to P's material and it came out as expected.

-Holden Profit