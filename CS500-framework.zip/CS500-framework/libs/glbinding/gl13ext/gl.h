#pragma once

#include <glbinding/nogl.h>

#include <glbinding/gl/extension.h>
#include <glbinding/gl13ext/types.h>
#include <glbinding/gl13ext/boolean.h>
#include <glbinding/gl13ext/values.h>
#include <glbinding/gl13ext/bitfield.h>
#include <glbinding/gl13ext/enum.h>
#include <glbinding/gl13ext/functions.h>
