#pragma once

#include <glbinding/nogl.h>

#include <glbinding/gl/extension.h>
#include <glbinding/gl40core/types.h>
#include <glbinding/gl40core/boolean.h>
#include <glbinding/gl40core/values.h>
#include <glbinding/gl40core/bitfield.h>
#include <glbinding/gl40core/enum.h>
#include <glbinding/gl40core/functions.h>
