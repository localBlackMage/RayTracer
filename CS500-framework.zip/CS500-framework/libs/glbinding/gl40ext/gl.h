#pragma once

#include <glbinding/nogl.h>

#include <glbinding/gl/extension.h>
#include <glbinding/gl40ext/types.h>
#include <glbinding/gl40ext/boolean.h>
#include <glbinding/gl40ext/values.h>
#include <glbinding/gl40ext/bitfield.h>
#include <glbinding/gl40ext/enum.h>
#include <glbinding/gl40ext/functions.h>
