#pragma once

#include <glbinding/nogl.h>

#include <glbinding/gl/extension.h>
#include <glbinding/gl21/types.h>
#include <glbinding/gl21ext/types.h>
#include <glbinding/gl21/boolean.h>
#include <glbinding/gl21ext/boolean.h>
#include <glbinding/gl21/values.h>
#include <glbinding/gl21ext/values.h>
#include <glbinding/gl21/bitfield.h>
#include <glbinding/gl21ext/bitfield.h>
#include <glbinding/gl21/enum.h>
#include <glbinding/gl21ext/enum.h>
#include <glbinding/gl21/functions.h>
#include <glbinding/gl21ext/functions.h>
